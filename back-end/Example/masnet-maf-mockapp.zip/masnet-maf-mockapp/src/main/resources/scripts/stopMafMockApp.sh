#!/bin/bash
kill $(ps aux | grep 'mafMockApp-1.0.jar' | grep -v 'grep' | awk '{print $2}')
