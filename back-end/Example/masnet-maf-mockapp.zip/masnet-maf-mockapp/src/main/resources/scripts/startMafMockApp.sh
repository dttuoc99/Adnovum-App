#!/bin/bash
APP_DIR=/home/nvluser/mockapp
/usr/bin/java -jar ${APP_DIR}/mafMockApp-1.0.jar --logging.level.root=INFO &> ${APP_DIR}/mocked-app.log
