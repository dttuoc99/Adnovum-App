package adnovum.maf.mocked.app.controller;

import adnovum.maf.mocked.app.util.NinjaUtil;
import ch.nevis.ninja.commons.token.NinjaTokenPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpSession;
import java.security.Principal;
import java.util.Map;

@Controller
public class OperaController extends GeneralController {

  @RequestMapping(value = { "/opera/" }, method = { RequestMethod.GET, RequestMethod.POST })
  public String getRequestLandingPage(Model model, Principal principal) {
    return "loginPageOpera";
  }

  @GetMapping(value = { "/opera/Public/Login/Secured/", "/opera/Public/Login/Secured/index.htm"})
  public String homePage(Model model, HttpSession session, Principal principal) {
    if (principal == null) {
      return "redirect:/opera/";
    }
    Map<String, String> userAttributes = NinjaUtil.getUserAttributes((NinjaTokenPrincipal) principal);
    wrapTextForRoles(userAttributes);
    model.addAllAttributes(userAttributes);

    return "homeOpera";
  }
}
