
package adnovum.maf.mocked.app.controller;

import java.security.Principal;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.GetMapping;

import adnovum.maf.mocked.app.util.NinjaUtil;
import ch.nevis.ninja.commons.token.NinjaTokenPrincipal;

@Controller
public class PortalController extends GeneralController {

  @RequestMapping(value = { "/portal/" }, method = { RequestMethod.GET, RequestMethod.POST })
  public String getRequestLoginPage(Model model, Principal principal) {
    return "loginPagePortal";
  }

  @GetMapping(value = { "/portal/auth/", "/portal/private/" })
  public String getRequestLandingPage(Model model, Principal principal) {
    if (principal == null) {
      return "redirect:/portal/";
    }
    Map<String, String> userAttributes = NinjaUtil.getUserAttributes((NinjaTokenPrincipal) principal);
    wrapTextForRoles(userAttributes);
    model.addAllAttributes(userAttributes);
    return "homePortal";
  }

}
