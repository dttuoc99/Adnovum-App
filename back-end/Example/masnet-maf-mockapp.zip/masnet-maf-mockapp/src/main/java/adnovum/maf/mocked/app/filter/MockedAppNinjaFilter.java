package adnovum.maf.mocked.app.filter;

import ch.nevis.ninja.filter.NinjaAuthenticationFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

public class MockedAppNinjaFilter extends NinjaAuthenticationFilter {
    Logger logger = LoggerFactory.getLogger(MockedAppNinjaFilter.class);

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        super.doFilter(req, res, chain);
        logger.info("MockedAppNinjaFilter filter the " + req.getRemoteAddr());
    }
}
