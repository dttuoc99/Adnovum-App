
package adnovum.maf.mocked.app.controller;

import java.util.Map;

public abstract class GeneralController {

  protected void wrapTextForRoles(Map<String, String> userAttributes) {
    String roles = userAttributes.get("roles");
    String refinedRoles = roles.replaceAll(",", ",\n");
    userAttributes.put("roles", refinedRoles);
  }
}
