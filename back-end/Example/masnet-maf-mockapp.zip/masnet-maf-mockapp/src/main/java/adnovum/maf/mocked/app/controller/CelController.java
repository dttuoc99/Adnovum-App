package adnovum.maf.mocked.app.controller;

import adnovum.maf.mocked.app.util.NinjaUtil;
import ch.nevis.ninja.commons.token.NinjaTokenPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.security.Principal;
import java.util.Map;

@Controller
public class CelController {

    @RequestMapping(
        value = {"/cel/", "/cel/index.htm"}, 
        method = { RequestMethod.GET, RequestMethod.POST }
    )
    public String getRequestLandingPage(Model model, Principal principal) {
        return "loginPageCel";
    }

    @GetMapping(value = {"/cel/Submission/", "/cel/Submission/index.htm"})
    public String getRequestHomepage(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/cel/";
        }
        Map<String, String> userAttributes = NinjaUtil.getUserAttributes((NinjaTokenPrincipal) principal);
        model.addAllAttributes(userAttributes);
        return "homeCel";
    }
}