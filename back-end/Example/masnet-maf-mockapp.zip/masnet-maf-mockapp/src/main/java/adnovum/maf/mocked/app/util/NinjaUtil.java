package adnovum.maf.mocked.app.util;

import ch.nevis.ninja.commons.token.NinjaTokenPrincipal;

import java.util.Collections;
import java.util.Map;

public final class NinjaUtil {

    private NinjaUtil(){
        // Nothing
    }
    
    @SuppressWarnings("unchecked")
    public static Map<String, String> getUserAttributes(NinjaTokenPrincipal principal) {
      // get token as String, can be forwarded to further token-consuming services
      return principal == null ? Collections.emptyMap() : principal.getAttributes();
    }
}
