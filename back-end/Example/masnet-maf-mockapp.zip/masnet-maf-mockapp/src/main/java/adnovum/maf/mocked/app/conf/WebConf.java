package adnovum.maf.mocked.app.conf;

import ch.nevis.ninja.filter.NinjaAuthenticationFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class WebConf {

    Logger logger = LoggerFactory.getLogger(WebConf.class);

    @Bean
    public FilterRegistrationBean<NinjaAuthenticationFilter> loggingFilter() throws ServletException, ReflectiveOperationException, NamingException {
        FilterRegistrationBean<NinjaAuthenticationFilter> ninjaFilterReg =
                new FilterRegistrationBean<>(new NinjaAuthenticationFilter());
        ninjaFilterReg.addInitParameter("NevisSignerCertificate", "/var/opt/neviskeybox/default/nevis/truststore.jks");
        ninjaFilterReg.addInitParameter("LogDebug", "true");
        ninjaFilterReg.addInitParameter("LogoutURI", "?logout");
        List<String> urlPatterns = new ArrayList<>();
        urlPatterns.add("/ssb/portal/*");
        urlPatterns.add("/cel/Submission/*");
        urlPatterns.add("/sprs/Public/Login/Secured/*");
        urlPatterns.add("/portal/auth/*");
        urlPatterns.add("/portal/private/*");
        urlPatterns.add("/opera/Public/Login/Secured/*");
        urlPatterns.add("/sgseapps/index.html");
        ninjaFilterReg.setUrlPatterns(urlPatterns);
        ninjaFilterReg.setName("MockedAppNinjaFilter");
        ninjaFilterReg.setOrder(1);

        //Dev Mode for anyone need to tried in the future
        // Replace the path to cert and key
//        ninjaFilterReg.addInitParameter("NevisSignerCertificate", "/home/trung/projects/masnet-maf/masnet-maf-mockapp/src/main/resources/keystore/truststore.jks");
//        ninjaFilterReg.addInitParameter("DevMode", "true");
//        ninjaFilterReg.addInitParameter("DevDir", "/home/trung/projects/masnet-maf/masnet-maf-mockapp/src/main/resources/dev_mode/sectokens");
//        ninjaFilterReg.addInitParameter("DevTokenSignerCert", "/home/trung/projects/masnet-maf/masnet-maf-mockapp/src/main/resources/keystore/truststore.jks?alias=mockedapp");
//        ninjaFilterReg.addInitParameter("DevTokenSignerKey", "/home/trung/projects/masnet-maf/masnet-maf-mockapp/src/main/resources/keystore/mockedapp_keystore.jks");
//        ninjaFilterReg.addInitParameter("DevTokenSignerKeyPassphrase", "password");
//        ninjaFilterReg.addInitParameter("DevPassword", "ninja");

        logger.info("Ninja Plugin configured and enabled");

        return ninjaFilterReg;
    }
}
